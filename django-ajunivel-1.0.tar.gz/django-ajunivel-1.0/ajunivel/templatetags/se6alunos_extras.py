from django import template

register = template.Library()