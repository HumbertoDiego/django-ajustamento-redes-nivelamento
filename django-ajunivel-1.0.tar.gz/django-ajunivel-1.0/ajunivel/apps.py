from django.apps import AppConfig

class AjunivelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ajunivel'
