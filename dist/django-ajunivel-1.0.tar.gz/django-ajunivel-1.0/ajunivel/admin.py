from django.contrib import admin
from .models import dp, successcount

admin.site.register(dp)
admin.site.register(successcount)